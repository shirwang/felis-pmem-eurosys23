#ifndef INDEX_H
#define INDEX_H

#include "index_common.h"
#include "masstree_index_impl.h"
#include "dptree_index_impl.h"
#include "hashtable_index_impl.h"

#endif /* INDEX_H */
